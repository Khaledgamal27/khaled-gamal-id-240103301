#include<iostream>
using namespace std ;
struct node
        {
        int data ;
        node * next ;

        };
        
    ;
class linked_list{
        node * head ;
    linked_list(){
        head = NULL;
    };
   void add_at_start(int x){
    node* new_node = new node();
    
    if (head== NULL){
        head = new_node;
        new_node->next = NULL;
        new_node->data = x ; 
    }
    else{
        new_node->data = x ;
        new_node->next = head ;
        head = new_node ;
    }

   }
   void append_at_end(int x){
    node * last_element ;  
    last_element = head ;
    while (last_element->next !=NULL)
    {
        last_element=last_element->next;
    }
    node* new_node = new node();
    last_element->next=new_node;
    new_node->next=NULL;
    new_node->data=x;


    

   }
   void add_spacific(int value,int index){
   int c;
    while (x.next !=Null && int index){
        x=x.next;
        c=c+1;
    }
    {
        /* code */
    }
    
}

    viod add_at_after_node_have_specific_data(int data , int after_data){
       node * new_node = new node();
       new_node->data = data ;
       node * after_node = head ;
       while (after_node->data != after_data){
           after_node = after_node->next ;
       }
       new_node->next = after_node->next ;
       after_node->next=new_node;

        
    };

    
    
