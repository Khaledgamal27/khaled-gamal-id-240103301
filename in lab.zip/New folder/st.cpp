#include <iostream>
using namespace std;
class stack{

public:
stack(int x){
    size=x;
    int top=-1;
    int arr[size];
}
 int empty(){
    if (top==-1){
        return -1;
    }
    else if(top==size-1){
        return 1;
    }
 }
 void push(int z){
    if(top==size-1){
        cout<<"is full";
    }
    else{
        arr[top++]=z;
    }
 }
 int pop(){
    if (top==-1){
        cout<<"is empty";
    }
    else{
        return arr[--top];
    }
 }
 
 void display(){
     if(top=-1){
        cout<<"is empty";
     }
     else{
        for (int y=0;y<size;y++){
            cout<<arr[y]<<"";

        }
     }


 }







}
int main(){
stack s(6);
s.push(2);
s.push(3);
s.push(4);
s.push(5);
s.push(6);
s.push(7);
s.pop();
s.display();


}

