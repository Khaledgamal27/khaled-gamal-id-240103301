#include <iostream>
using namespace std;
struct node {
int data;
    node*next;

};
class linked_list4{
    node*head;
public:
    linked_list4() {
        head=NULL;
    }
    void insert_in_start(int value) {
        node*newnode=new node();
        if (head==NULL) {
            head=newnode;
            newnode->data=value;
            newnode->next=NULL;
        }
        else {
            newnode->data=value;
            newnode->next=head;
            head=newnode;

        }


    }

    void insert_in_end(int value) {
        node*newnode=new node();
        node*last;
        if (head==NULL) {
            head=newnode;
            newnode->data=value;
            newnode->next=NULL;
        }
        else {

            last=head;

            newnode->data=value;
            while (last->next !=NULL) {
                last=last->next;
            }
            last->next=newnode;
            newnode->next=NULL;


        }
    }
void append(int value) {
        node*newnode=new node();
        while ()
    }


};

int main() {
linked_list4 s;
    s.insert_in_start(3);
    s.insert_in_start(4);
    s.insert_in_start(5);
    s.insert_in_end(6);

}
