#include <iostream>
using namespace std;
#define size 10;//ثبت الsize 10//
// public int size=10
stack(intx){
    cout<<x;
}
stack(){
    int top=-1;
}
class stack{
    int top=-1;
int arr[size];
//int arr[10];
int push(int x){
    if (top>=size-1){
        return -1;
    }
else{
    arr[++top]=x;
    return arr[top];
}

}

void pop(){
    if (top<0){//هنا فارغه
    cout<<"stack is full";}
else{//هنا هنطبع وبعد كدا هنقص 1
    cout<<arr[top--];//اطبع بعد كدا نقص 1
    //=cout<<arr[top]; top--      print first second mainc 
}
}
void print_topvalue(){
    cout<< arr[top];
    cout<<top;
}
}
class queue{
int rear;
int front;
    queue(){ 
        front =-1;
        rear=0;
    }
ant q[6];
int enqueue(int x){
    front=0;
    rear++;

}
 int dequeue(){

 }






}
// stack implemmentation
int main(){
stack s1;
s1.push(5);
s1.push(10);
s1.push(15);
s1.push(20);
s1.push(25);

s1.pop();
s1.pop();
s1.pop();
s1.pop();


    return 0;
}
