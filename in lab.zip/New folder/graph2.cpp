#include<iostream>
using  namespace std;
class node {
    public:
    int vertex;
    node *next;
    int weight;
    node(int v, int w) {
        vertex = v;
        weight = w;
        next = NULL;
    }
};
class graph {
private:
    int vertices;
    bool directed;
    bool weighted;
    int matrix[10][10];
    node*list[10];
    public://constructor
    graph(int v,bool isdirected,bool isweighted) {
        vertices=v;
        directed=isdirected;
        weighted=isweighted;
        //initilize matrix
        for(int i=0;i<vertices;i++) {
            for(int j=0;j<vertices;j++) {
                matrix[i][j]=0;
            }

        }
        for(int i=0;i<vertices;i++) {
            list[i]=NULL;
        }
    }

        void addedg(int from,int to ,int weight=1){

       int w=weighted?weight:1;
        matrix[from][to]=w;
        if (directed) {
            matrix[to][from]=w;
        }
        node* newnode=new node(to,w);
        newnode->next=list[from];
        list[from]=newnode;

        if (!directed) {
            node* reversenode=new node(from,w);
            reversenode->next=list[to];
            list[to]=reversenode;
        }
    }

    void printmatrix() {

    }


};











