#include <iostream>

using namespace std;

class Stack {
 int MAX_SIZE = 4;
 int arr[MAX_SIZE];
 int top;

public:
    SimpleStack() {
        top = -1;
    }

    bool isFull() {
        return top == MAX_SIZE - 1;
    }

    bool isEmpty() {
        return top == -1;
    }

    void push(int value) {
        if (isFull()) {
            cout << " Stack Overflow Cannot push " << value << ". The stack is full." << endl;
            return;
        }
        top++;
        arr[top] = value;
        cout << " Pushed element: " << value << endl;
    }

    int pop() {
        if (isEmpty()) {
            cout << " Stack Underflow! Cannot pop element. The stack is empty." << endl;
            return -1;
        }
        int popped_value = arr[top];
        top--;
        cout << " Popped element: " << popped_value << endl;
        return popped_value;
    }

    int peek() {
        if (isEmpty()) {
            cout << "Stack is empty. No top element." << endl;
            return -1;
        }
        return arr[top];
    }
};

int main() {
    SimpleStack myStack;

    cout << "Testing " << endl;
    myStack.push(10);
    myStack.push(20);
    myStack.push(30);
    myStack.push(40);

    myStack.push(50);

    cout << "Current Top " << myStack.peek() << endl;

    cout << "Testing Pop" << endl;
    myStack.pop();
    myStack.pop();

    cout << "Top after two pops " << myStack.peek() << endl;

    myStack.pop();
    myStack.pop();

    myStack.pop();

    return 0;
}