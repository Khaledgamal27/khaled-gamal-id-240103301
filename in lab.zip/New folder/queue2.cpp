#include <iostream>
using namespace std;
class queue{
// int size=5;
// int arr[size];
// int front=-1;
// int rear=-1;
int size;
int arr[];
int front;
int rear;
queue(int t){
    int size=t;
    int arr[size];
    int front=-1;
    int rear=-1;
}
void enqueue(int x){
    if (front==size-1 && rear==0){
        cuot<<"is full";
    }

    else if(front==-1 && rear==-1){
       raer++;
       arr[front++]=z;

    }
    else if (front==size-1 && raer!=0){
        front=0
        arr[front]=z;
    }
    else if (front!=size-1&& rear==0){
        arr[front++]=z;
    }
    else if (front !=size && rear!=0){
        arr[front++]=z;
    }
    else if(front==rear-1){
        cout<<"is full";
    }
}

int dequeue(){
    if(rear==-1){
        cout<<"is empty";
    }
    else{
        return arr[rea++];
    }
}
void display(){
if(front==-1 && rear==-1){
    cout<<"is empty";
}
else{
    for(int i=rear;i<=front;i++){
        cout<<arr[i];
    }
}




}






}



int main(){

}