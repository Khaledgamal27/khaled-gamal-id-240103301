#include <iostream>
using namespace std;
class program{

    int size;
    int rear;
    int front;

program(int x){
     size=x;
     
     front=-1;
     rear=-1;
}
int arr[size];
bool empty(){
return front==-1;

}
bool full(){
    return front==size-1;
}

void enqueue(int z){
    if(full()){
        cout<<"is full";

    }
    else{
        arr[front++]=z;
    }
}

int dequeue(){
     if(empty()){
        cout<<"this empty";
     }
     else{
        return arr[rear++];
     }



}

void display (){
    if (empty()){
        cout<<"is empty";
    }
    else{
        for(int i=rear;i<=front;i++){

          cout<<arr[i];


        }
    }



}



}

int main(){
    program p(3);
    p.enqueue(1);
    p.enqueue(2);
    p.enqueue(3);
    p.dequeue();
    p.display();
}