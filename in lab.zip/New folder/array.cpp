#include <iostream>
using namespace std;
void number(){
     int x;
     cin>>x;
    int arr[x];
    int largest;
    
    int sum=0;
   
    for (int z=0;z<x;z++){
        int r;
        cin>>r;
        arr[z]=r;
        
    }
    largest=arr[0];
    for(int z=0;z<x;z++){
        sum+=arr[z];
        if (arr[z]>largest){
         
        largest=arr[z];
            
            
     }
    
    
    
    
     }
     float avg=sum/x;
    // float avg = static_cast<float>(sum) / x;
    cout<<"largest"<<largest;
    cout<<"avg"<<avg;
}
    
   int main(){
       number();
       return 0;
   
    
    
}