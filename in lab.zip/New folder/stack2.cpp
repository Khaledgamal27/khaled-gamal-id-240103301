#include <iostream>
using namespace std;

class  stack{
int top;
int size;
stack(int x){
     size=x;
     
     top=-1;
}
int arr[size];

void push(int z){
    if (size ==top-1){
        cout<<"this full"<<endl;
    }
    else{
        arr[++top]=z;

    }
}

int pop(){
    if (top==-1){
        cout<<"is empty";

    }
    else{
        return arr[top--];
    }
}}
int main(){
push(2);
push(3);
push(5);






}


