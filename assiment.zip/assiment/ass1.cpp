#include <iostream>
using namespace std;

#define MAX 100

class Stack {
    int arr[MAX];
    int topIndex;

public:
    Stack() { topIndex = -1; }

    bool isEmpty() { return topIndex == -1; }
    bool isFull() { return topIndex == MAX - 1; }

    void push(int value) {
        if (!isFull())
            arr[++topIndex] = value;
        else
            cout << "Stack Overflow!" << endl;
    }

    int pop() {
        if (!isEmpty())
            return arr[topIndex--];
        else {
            cout << "Stack Underflow!" << endl;
            return -1;
        }
    }

    int peek() {
        if (!isEmpty())
            return arr[topIndex];
        else {
            cout << "Stack is empty!" << endl;
            return -1;
        }
    }
};

bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

int precedence(char op) {
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

string infixToPostfix(string expr) {
    Stack s;
    string postfix = "";

    for (int i = 0; i < expr.length(); i++) {
        char c = expr[i];

        if (c >= '0' && c <= '9') {
            postfix += c;
            postfix += ' ';
        }
        else if (c == '(') {
            s.push(c);
        }
        else if (c == ')') {
            while (!s.isEmpty() && s.peek() != '(') {
                postfix += (char)s.pop();
                postfix += ' ';
            }
            if (!s.isEmpty() && s.peek() == '(')
                s.pop();
        }
        else if (isOperator(c)) {
            while (!s.isEmpty() && precedence(c) <= precedence((char)s.peek())) {
                postfix += (char)s.pop();
                postfix += ' ';
            }
            s.push(c);
        }
    }

    while (!s.isEmpty()) {
        postfix += (char)s.pop();
        postfix += ' ';
    }

    return postfix;
}

int evaluatePostfix(string expr) {
    Stack s;
    for (int i = 0; i < expr.length(); i++) {
        char c = expr[i];

        if (c >= '0' && c <= '9') {
            s.push(c - '0');
        }
        else if (isOperator(c)) {
            int b = s.pop();
            int a = s.pop();
            int result = 0;

            switch(c) {
                case '+': result = a + b; break;
                case '-': result = a - b; break;
                case '*': result = a * b; break;
                case '/':
                    if (b != 0) result = a / b;
                    else {
                        cout << "Error: Division by zero!" << endl;
                        return 0;
                    }
                    break;
            }
            s.push(result);
        }
    }

    return s.pop();
}

int main() {
    string infix;
    cout << "Enter an infix expression (single-digit numbers only): ";
    cin >> infix;

    string postfix = infixToPostfix(infix);
    cout << "Postfix Expression: " << postfix << endl;

    int result = evaluatePostfix(postfix);
    cout << "Result: " << result << endl;

    return 0;
}
