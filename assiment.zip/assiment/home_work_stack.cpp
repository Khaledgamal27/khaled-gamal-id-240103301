#include <iostream>
#include <string>
#include <sstream>
using namespace std;

const int MAXSIZE = 100;

class IntStack {
    int arr[MAXSIZE];
    int top;

public:
    IntStack() {
        top = -1;
    }

    bool isEmpty() {
        return top == -1;
    }

    bool isFull() {
        return top == MAXSIZE - 1;
    }

    void push(int x) {
        if (isFull()) {
            cout << "Stack Overflow\n";
        } else {
            arr[++top] = x;
        }
    }

    int pop() {
        if (isEmpty()) {
            cout << "Stack Underflow\n";
            return -1;
        } else {
            return arr[top--];
        }
    }

    int peek() {
        if (isEmpty()) {
            cout << "Stack Empty\n";
            return -1;
        } else {
            return arr[top];
        }
    }
};

class CharStack {
    char arr[MAXSIZE];
    int top;

public:
    CharStack() {
        top = -1;
    }

    bool isEmpty() {
        return top == -1;
    }

    bool isFull() {
        return top == MAXSIZE - 1;
    }

    void push(char x) {
        if (isFull()) {
            cout << "Stack Overflow\n";
        } else {
            arr[++top] = x;
        }
    }

    char pop() {
        if (isEmpty()) {
            cout << "Stack Underflow\n";
            return '\0';
        } else {
            return arr[top--];
        }
    }

    char peek() {
        if (isEmpty()) {
            return '\0';
        } else {
            return arr[top];
        }
    }
};

int precedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

string infixToPostfix(string infix) {
    CharStack s;
    string postfix = "";

    for (int i = 0; i < infix.length(); i++) {
        char ch = infix[i];

        if (ch == ' ') continue;

        if (ch >= '0' && ch <= '9') {
            postfix += ch;
            postfix += ' ';
        }
        else if (ch == '(') {
            s.push(ch);
        }
        else if (ch == ')') {
            while (!s.isEmpty() && s.peek() != '(') {
                postfix += s.pop();
                postfix += ' ';
            }
            if (s.isEmpty()) {
                cout << "Error: Mismatched Parentheses\n";
                return "";
            }
            s.pop();
        }
        else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            while (!s.isEmpty() && precedence(s.peek()) >= precedence(ch)) {
                postfix += s.pop();
                postfix += ' ';
            }
            s.push(ch);
        }
        else {
            cout << "Invalid Character Found\n";
            return "";
        }
    }

    while (!s.isEmpty()) {
        if (s.peek() == '(') {
            cout << "Error: Mismatched Parentheses\n";
            return "";
        }
        postfix += s.pop();
        postfix += ' ';
    }

    return postfix;
}

int evaluatePostfix(string postfix) {
    IntStack s;
    string token;
    istringstream iss(postfix);

    while (iss >> token) {
        if (isdigit(token[0])) {
            s.push(token[0] - '0');
        }
        else {
            int b = s.pop();
            int a = s.pop();
            int result;

            switch (token[0]) {
                case '+': result = a + b; break;
                case '-': result = a - b; break;
                case '*': result = a * b; break;
                case '/':
                    if (b == 0) {
                        cout << "Error: Division by zero\n";
                        return -1;
                    }
                    result = a / b;
                    break;
                default:
                    cout << "Invalid Operator\n";
                    return -1;
            }

            s.push(result);
        }
    }

    return s.pop();
}

int main() {
    string infix;

    cout << "Enter Infix Expression:\n";
    getline(cin, infix);

    string postfix = infixToPostfix(infix);
    if (postfix == "") return 0;

    cout << "Postfix Expression: " << postfix << endl;

    int result = evaluatePostfix(postfix);
    cout << "Final Result: " << result << endl;

    return 0;
}
