#include <iostream>
using namespace std;

struct node {
    int data;
    node* next;
    node* prev;
};

class Circular {
public:
    node* head;
    node* tail;

    Circular() {
        head = NULL;
        tail = NULL;
    }

    bool empty() {
        return head == NULL;
    }

    void add_start(int x) {
        node* newNode = new node();
        newNode->data = x;

        if (empty()) {
            newNode->next = newNode->prev = newNode;
            head = tail = newNode;
        } else {
            newNode->next = head;
            newNode->prev = tail;
            head->prev = newNode;
            tail->next = newNode;
            head = newNode;
        }
    }

    void add_end(int x) {
        node* newNode = new node();
        newNode->data = x;

        if (empty()) {
            newNode->next = newNode->prev = newNode;
            head = tail = newNode;
        } else {
            newNode->prev = tail;
            newNode->next = head;
            tail->next = newNode;
            head->prev = newNode;
            tail = newNode;
        }
    }

    void add_specific_before(int key, int x) {
        if (empty()) return;

        node* temp = head;

        do {
            if (temp->data == key) {
                if (temp == head) {
                    add_start(x);
                } else {
                    node* newNode = new node();
                    newNode->data = x;

                    newNode->next = temp;
                    newNode->prev = temp->prev;
                    temp->prev->next = newNode;
                    temp->prev = newNode;
                }
                return;
            }
            temp = temp->next;
        } while (temp != head);
    }

    void add_specific_after(int key, int x) {
        if (empty()) return;

        node* temp = head;

        do {
            if (temp->data == key) {
                node* newNode = new node();
                newNode->data = x;

                newNode->next = temp->next;
                newNode->prev = temp;
                temp->next->prev = newNode;
                temp->next = newNode;

                if (temp == tail)
                    tail = newNode;
                return;
            }
            temp = temp->next;
        } while (temp != head);
    }

    void delete_start() {
        if (empty()) return;

        node* temp = head;

        if (head == tail) {
            delete temp;
            head = tail = NULL;
        } else {
            head = head->next;
            tail->next = head;
            head->prev = tail;
            delete temp;
        }
    }

    void delete_end() {
        if (empty()) return;

        node* temp = tail;

        if (head == tail) {
            delete temp;
            head = tail = NULL;
        } else {
            tail = tail->prev;
            tail->next = head;
            head->prev = tail;
            delete temp;
        }
    }

    void delete_specific(int key) {
        if (empty()) return;

        node* temp = head;

        do {
            if (temp->data == key) {
                if (temp == head) delete_start();
                else if (temp == tail) delete_end();
                else {
                    temp->prev->next = temp->next;
                    temp->next->prev = temp->prev;
                    delete temp;
                }
                return;
            }
            temp = temp->next;
        } while (temp != head);
    }

    void print(int n = 20) {
        if (empty()) return;
        node* temp = head;
        int count = 0;
        do {
            cout << temp->data << " ";
            temp = temp->next;
            count++;
        } while (temp != head && count < n);
        cout << endl;
    }
};

int main() {
    Circular list;

    list.add_end(10);
    list.add_end(20);
    list.add_end(30);
    list.add_start(5);
    list.add_specific_before(20, 15);
    list.add_specific_after(20, 25);

    cout << "list: ";
    list.print();

    list.delete_start();
    list.delete_end();
    list.delete_specific(20);

    cout << "After deletions: ";
    list.print();

    return 0;
}
