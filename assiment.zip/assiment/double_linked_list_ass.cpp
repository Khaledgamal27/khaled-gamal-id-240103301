#include <iostream>
using namespace std;

struct node {
    int data;
    node* next;
    node* prev;
};

class data {
public:
    node* head;
    node* tail;

    data() {
        head = NULL;
        tail = NULL;
    }

    bool empty() {
        return head == NULL;
    }

    void add_start(int x) {
        node* newNode = new node();
        newNode->data = x;

        if (empty()) {
            newNode->prev = NULL;
            newNode->next = NULL;
            head = tail = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            newNode->prev = NULL;
            head = newNode;
        }
    }

    void add_end(int x) {
        node* newNode = new node();
        newNode->data = x;

        if (empty()) {
            newNode->prev = NULL;
            newNode->next = NULL;
            head = tail = newNode;
        } else {
            newNode->prev = tail;
            tail->next = newNode;
            newNode->next = NULL;
            tail = newNode;
        }
    }

    void add_specific_before(int key, int x) {
        if (empty()) return;

        node* temp = head;

        if (head->data == key) {
            add_start(x);
            return;
        }

        while (temp != NULL && temp->data != key)
            temp = temp->next;

        if (temp == NULL) return;

        node* newNode = new node();
        newNode->data = x;

        newNode->next = temp;
        newNode->prev = temp->prev;
        temp->prev->next = newNode;
        temp->prev = newNode;
    }

    void add_specific_after(int key, int x) {
        if (empty()) return;

        node* temp = head;
        while (temp != NULL && temp->data != key)
            temp = temp->next;

        if (temp == NULL) return;

        node* newNode = new node();
        newNode->data = x;

        newNode->prev = temp;
        newNode->next = temp->next;

        if (temp->next != NULL)
            temp->next->prev = newNode;
        else
            tail = newNode;

        temp->next = newNode;
    }

    void delete_start() {
        if (empty()) return;

        node* temp = head;

        if (head == tail) head = tail = NULL;
        else {
            head = head->next;
            head->prev = NULL;
        }

        delete temp;
    }

    void delete_end() {
        if (empty()) return ;

        node* temp = tail;

        if (head == tail)
            { head = tail = NULL;}
        else {
            tail = tail->prev;
            tail->next = NULL;
        }

        delete temp;
    }

    void delete_specific(int key) {
        if (empty()) return;

        node* temp = head;

        while (temp != NULL && temp->data != key)
            temp = temp->next;

        if (temp == NULL) return;

        if (temp == head) delete_start();
        else if (temp == tail) delete_end();
        else {
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
            delete temp;
        }
    }

    void print() {
        node* temp = head;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

