#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
};

Node* createNode(int x) {
    Node* n = new Node();
    n->data = x;
    n->left = NULL;
    n->right = NULL;
    return n;
}

#define MAX 50

class Stack {
    Node* arr[MAX];
    int top;

public:
    Stack() {
        top = -1;
    }

    bool isEmpty() {
        return top == -1;
    }

    void push(Node* x) {
        if (top < MAX - 1)
            arr[++top] = x;
    }

    Node* pop() {
        if (!isEmpty())
            return arr[top--];
        return NULL;
    }
};

void inorderUsingStack(Node* root) {
    Stack s;
    Node* cur = root;

    while (cur != NULL || !s.isEmpty()) {
        while (cur != NULL) {
            s.push(cur);
            cur = cur->left;
        }
        cur = s.pop();
        cout << cur->data << " ";
        cur = cur->right;
    }
}

int main() {
    Node* root = createNode(1);
    root->left = createNode(2);
    root->right = createNode(3);
    root->left->left = createNode(4);
    root->left->right = createNode(5);

    inorderUsingStack(root);
    return 0;
}